%{

#include "symbol_table.h"

#define YYSTYPE symbol_info*

extern FILE *yyin;
int yyparse(void);
int yylex(void);
extern YYSTYPE yylval;

// ── symbol table ─────────────────────────────────────────────────────────────
symbol_table *symtab = nullptr;

// ── misc globals ─────────────────────────────────────────────────────────────
int lines = 1;
ofstream outlog;

// ── helpers for variable declarations ────────────────────────────────────────
struct VarDecl {
    string name;
    bool   is_array;
    int    array_size;
};
vector<VarDecl> collected_vars;   // filled while parsing declaration_list

// ── helpers for function parameters ──────────────────────────────────────────
struct ParamInfo {
    string name;   // "" if unnamed (e.g. "int" with no id)
    string type;
};
vector<ParamInfo> pending_params;
string pending_param_details;
int    pending_param_count = 0;

// ── helpers for function definition ──────────────────────────────────────────
string pending_func_name;
string pending_func_return_type;

// ─────────────────────────────────────────────────────────────────────────────

void yyerror(char *s)
{
    outlog << "At line " << lines << " " << s << endl << endl;
    // reset per-declaration helpers to avoid corrupt state
    collected_vars.clear();
    pending_params.clear();
    pending_param_details = "";
    pending_param_count   = 0;
}

%}

%token IF ELSE FOR WHILE DO BREAK INT CHAR FLOAT DOUBLE VOID RETURN
%token SWITCH CASE DEFAULT CONTINUE PRINTLN
%token ADDOP MULOP INCOP DECOP RELOP ASSIGNOP LOGICOP NOT
%token LPAREN RPAREN LCURL RCURL LTHIRD RTHIRD COMMA SEMICOLON
%token CONST_INT CONST_FLOAT ID

%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE

%%

start : program
    {
        outlog << "At line no: " << lines << " start : program " << endl << endl;
        outlog << "Symbol Table" << endl << endl;

        symtab->print_all_scopes(outlog);

        $$ = new symbol_info($1->getname(), "start");
    }
    ;

program : program unit
    {
        outlog << "At line no: " << lines << " program : program unit " << endl << endl;
        outlog << $1->getname() + "\n" + $2->getname() << endl << endl;

        $$ = new symbol_info($1->getname() + "\n" + $2->getname(), "program");
    }
    | unit
    {
        outlog << "At line no: " << lines << " program : unit " << endl << endl;
        outlog << $1->getname() << endl << endl;

        $$ = new symbol_info($1->getname(), "program");
    }
    ;

unit : var_declaration
     {
        outlog << "At line no: " << lines << " unit : var_declaration " << endl << endl;
        outlog << $1->getname() << endl << endl;

        $$ = new symbol_info($1->getname(), "unit");
     }
     | func_definition
     {
        outlog << "At line no: " << lines << " unit : func_definition " << endl << endl;
        outlog << $1->getname() << endl << endl;

        $$ = new symbol_info($1->getname(), "unit");
     }
     ;

/* ── function definitions ──────────────────────────────────────────────────── */

func_definition
    : type_specifier ID LPAREN parameter_list RPAREN
      {
          /* Store context needed after compound_statement's scope exits */
          pending_func_name        = $2->getname();
          pending_func_return_type = $1->getname();
          /* pending_params / pending_param_details / pending_param_count were
             filled in by parameter_list rules */
      }
      compound_statement
      {
          outlog << "At line no: " << lines
                 << " func_definition : type_specifier ID LPAREN parameter_list RPAREN compound_statement "
                 << endl << endl;
          outlog << $1->getname() << " " << $2->getname()
                 << "(" + $4->getname() + ")\n" << $7->getname() << endl << endl;

          /* Insert function into the current (parent) scope */
          symbol_info *func_sym = new symbol_info(pending_func_name, "ID");
          func_sym->set_symbol_kind("FUNCTION");
          func_sym->set_data_type(pending_func_return_type);
          func_sym->set_param_count(pending_param_count);
          func_sym->set_param_details(pending_param_details);
          if (!symtab->insert(func_sym)) {
              outlog << "Multiple declaration of " << pending_func_name << endl << endl;
              delete func_sym;
          }

          $$ = new symbol_info($1->getname() + " " + $2->getname()
                               + "(" + $4->getname() + ")\n" + $7->getname(),
                               "func_def");
      }
    | type_specifier ID LPAREN RPAREN
      {
          pending_func_name        = $2->getname();
          pending_func_return_type = $1->getname();
          pending_params.clear();
          pending_param_details = "";
          pending_param_count   = 0;
      }
      compound_statement
      {
          outlog << "At line no: " << lines
                 << " func_definition : type_specifier ID LPAREN RPAREN compound_statement "
                 << endl << endl;
          outlog << $1->getname() << " " << $2->getname() << "()\n" << $6->getname() << endl << endl;

          /* Insert function into the current (parent) scope */
          symbol_info *func_sym = new symbol_info(pending_func_name, "ID");
          func_sym->set_symbol_kind("FUNCTION");
          func_sym->set_data_type(pending_func_return_type);
          func_sym->set_param_count(0);
          func_sym->set_param_details("");
          if (!symtab->insert(func_sym)) {
              outlog << "Multiple declaration of " << pending_func_name << endl << endl;
              delete func_sym;
          }

          $$ = new symbol_info($1->getname() + " " + $2->getname()
                               + "()\n" + $6->getname(), "func_def");
      }
    ;

/* ── parameter list ─────────────────────────────────────────────────────────── */

parameter_list
    : parameter_list COMMA type_specifier ID
      {
          outlog << "At line no: " << lines
                 << " parameter_list : parameter_list COMMA type_specifier ID "
                 << endl << endl;
          outlog << $1->getname() << "," << $3->getname() << " " << $4->getname() << endl << endl;

          pending_params.push_back({$4->getname(), $3->getname()});
          if (!pending_param_details.empty()) pending_param_details += ", ";
          pending_param_details += $3->getname() + " " + $4->getname();
          pending_param_count++;

          $$ = new symbol_info($1->getname() + "," + $3->getname() + " " + $4->getname(),
                               "param_list");
      }
    | parameter_list COMMA type_specifier
      {
          outlog << "At line no: " << lines
                 << " parameter_list : parameter_list COMMA type_specifier "
                 << endl << endl;
          outlog << $1->getname() << "," << $3->getname() << endl << endl;

          pending_params.push_back({"", $3->getname()});
          if (!pending_param_details.empty()) pending_param_details += ", ";
          pending_param_details += $3->getname();
          pending_param_count++;

          $$ = new symbol_info($1->getname() + "," + $3->getname(), "param_list");
      }
    | type_specifier ID
      {
          outlog << "At line no: " << lines
                 << " parameter_list : type_specifier ID "
                 << endl << endl;
          outlog << $1->getname() << " " << $2->getname() << endl << endl;

          pending_params.clear();
          pending_params.push_back({$2->getname(), $1->getname()});
          pending_param_details = $1->getname() + " " + $2->getname();
          pending_param_count   = 1;

          $$ = new symbol_info($1->getname() + " " + $2->getname(), "param_list");
      }
    | type_specifier
      {
          outlog << "At line no: " << lines
                 << " parameter_list : type_specifier "
                 << endl << endl;
          outlog << $1->getname() << endl << endl;

          pending_params.clear();
          pending_params.push_back({"", $1->getname()});
          pending_param_details = $1->getname();
          pending_param_count   = 1;

          $$ = new symbol_info($1->getname(), "param_list");
      }
    ;

/* ── compound statement ─────────────────────────────────────────────────────── */
/*  A mid-rule action fires right after LCURL is shifted:
      1. Enter a new scope (logs "New ScopeTable with ID N created")
      2. Insert any pending function parameters into that scope
    When RCURL is reduced:
      3. Exit scope (prints all scopes + "Scopetable with ID N removed")         */

compound_statement
    : LCURL
      {
          symtab->enter_scope();

          /* Insert any pending function parameters */
          for (auto &p : pending_params) {
              if (!p.name.empty()) {
                  symbol_info *sym = new symbol_info(p.name, "ID");
                  sym->set_symbol_kind("VARIABLE");
                  sym->set_data_type(p.type);
                  if (!symtab->insert(sym)) {
                      outlog << "Multiple declaration of " << p.name << endl << endl;
                      delete sym;
                  }
              }
          }
          pending_params.clear();
      }
      statements RCURL
      {
          outlog << "At line no: " << lines
                 << " compound_statement : LCURL statements RCURL " << endl << endl;
          outlog << "{\n" + $3->getname() + "\n}" << endl << endl;

          symtab->exit_scope();

          $$ = new symbol_info("{\n" + $3->getname() + "\n}", "comp_stmnt");
      }
    | LCURL
      {
          symtab->enter_scope();
          pending_params.clear();
      }
      RCURL
      {
          outlog << "At line no: " << lines
                 << " compound_statement : LCURL RCURL " << endl << endl;
          outlog << "{\n}" << endl << endl;

          symtab->exit_scope();

          $$ = new symbol_info("{\n}", "comp_stmnt");
      }
    ;

/* ── variable declaration ────────────────────────────────────────────────────── */

var_declaration : type_specifier declaration_list SEMICOLON
    {
        outlog << "At line no: " << lines
               << " var_declaration : type_specifier declaration_list SEMICOLON "
               << endl << endl;
        outlog << $1->getname() << " " << $2->getname() << ";" << endl << endl;

        /* Insert all collected variables into the current scope */
        for (auto &v : collected_vars) {
            symbol_info *sym = new symbol_info(v.name, "ID");
            sym->set_data_type($1->getname());
            if (v.is_array) {
                sym->set_symbol_kind("ARRAY");
                sym->set_array_size(v.array_size);
            } else {
                sym->set_symbol_kind("VARIABLE");
            }
            if (!symtab->insert(sym)) {
                outlog << "Multiple declaration of " << v.name << endl << endl;
                delete sym;
            }
        }
        collected_vars.clear();

        $$ = new symbol_info($1->getname() + " " + $2->getname() + ";", "var_dec");
    }
    ;

type_specifier
    : INT
      {
          outlog << "At line no: " << lines << " type_specifier : INT " << endl << endl;
          outlog << "int" << endl << endl;
          $$ = new symbol_info("int", "type");
      }
    | FLOAT
      {
          outlog << "At line no: " << lines << " type_specifier : FLOAT " << endl << endl;
          outlog << "float" << endl << endl;
          $$ = new symbol_info("float", "type");
      }
    | VOID
      {
          outlog << "At line no: " << lines << " type_specifier : VOID " << endl << endl;
          outlog << "void" << endl << endl;
          $$ = new symbol_info("void", "type");
      }
    ;

/* ── declaration list ─────────────────────────────────────────────────────────
   Collect variable names so var_declaration can insert them with the right type. */

declaration_list
    : declaration_list COMMA ID
      {
          outlog << "At line no: " << lines
                 << " declaration_list : declaration_list COMMA ID "
                 << endl << endl;
          outlog << $1->getname() << "," << $3->getname() << endl << endl;

          collected_vars.push_back({$3->getname(), false, 0});

          $$ = new symbol_info($1->getname() + "," + $3->getname(), "dcl_list");
      }
    | declaration_list COMMA ID LTHIRD CONST_INT RTHIRD
      {
          outlog << "At line no: " << lines
                 << " declaration_list : declaration_list COMMA ID LTHIRD CONST_INT RTHIRD "
                 << endl << endl;
          outlog << $1->getname() << "," << $3->getname()
                 << "[" << $5->getname() << "]" << endl << endl;

          collected_vars.push_back({$3->getname(), true, stoi($5->getname())});

          $$ = new symbol_info($1->getname() + "," + $3->getname()
                               + "[" + $5->getname() + "]", "dcl_list");
      }
    | ID
      {
          outlog << "At line no: " << lines << " declaration_list : ID " << endl << endl;
          outlog << $1->getname() << endl << endl;

          collected_vars.clear();
          collected_vars.push_back({$1->getname(), false, 0});

          $$ = new symbol_info($1->getname(), "dcl_list");
      }
    | ID LTHIRD CONST_INT RTHIRD
      {
          outlog << "At line no: " << lines
                 << " declaration_list : ID LTHIRD CONST_INT RTHIRD "
                 << endl << endl;
          outlog << $1->getname() << "[" << $3->getname() << "]" << endl << endl;

          collected_vars.clear();
          collected_vars.push_back({$1->getname(), true, stoi($3->getname())});

          $$ = new symbol_info($1->getname() + "[" + $3->getname() + "]", "dcl_list");
      }
    ;

/* ── statements ──────────────────────────────────────────────────────────────── */

statements
    : statement
      {
          outlog << "At line no: " << lines << " statements : statement " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "stmnts");
      }
    | statements statement
      {
          outlog << "At line no: " << lines << " statements : statements statement " << endl << endl;
          outlog << $1->getname() << "\n" << $2->getname() << endl << endl;
          $$ = new symbol_info($1->getname() + "\n" + $2->getname(), "stmnts");
      }
    ;

statement
    : var_declaration
      {
          outlog << "At line no: " << lines << " statement : var_declaration " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "stmnt");
      }
    | expression_statement
      {
          outlog << "At line no: " << lines << " statement : expression_statement " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "stmnt");
      }
    | compound_statement
      {
          outlog << "At line no: " << lines << " statement : compound_statement " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "stmnt");
      }
    | FOR LPAREN expression_statement expression_statement expression RPAREN statement
      {
          outlog << "At line no: " << lines
                 << " statement : FOR LPAREN expression_statement expression_statement expression RPAREN statement "
                 << endl << endl;
          outlog << "for(" << $3->getname() << $4->getname() << $5->getname() << ")\n"
                 << $7->getname() << endl << endl;
          $$ = new symbol_info("for(" + $3->getname() + $4->getname() + $5->getname()
                               + ")\n" + $7->getname(), "stmnt");
      }
    | IF LPAREN expression RPAREN statement %prec LOWER_THAN_ELSE
      {
          outlog << "At line no: " << lines
                 << " statement : IF LPAREN expression RPAREN statement "
                 << endl << endl;
          outlog << "if(" << $3->getname() << ")\n" << $5->getname() << endl << endl;
          $$ = new symbol_info("if(" + $3->getname() + ")\n" + $5->getname(), "stmnt");
      }
    | IF LPAREN expression RPAREN statement ELSE statement
      {
          outlog << "At line no: " << lines
                 << " statement : IF LPAREN expression RPAREN statement ELSE statement "
                 << endl << endl;
          outlog << "if(" << $3->getname() << ")\n" << $5->getname()
                 << "\nelse\n" << $7->getname() << endl << endl;
          $$ = new symbol_info("if(" + $3->getname() + ")\n" + $5->getname()
                               + "\nelse\n" + $7->getname(), "stmnt");
      }
    | WHILE LPAREN expression RPAREN statement
      {
          outlog << "At line no: " << lines
                 << " statement : WHILE LPAREN expression RPAREN statement "
                 << endl << endl;
          outlog << "while(" << $3->getname() << ")\n" << $5->getname() << endl << endl;
          $$ = new symbol_info("while(" + $3->getname() + ")\n" + $5->getname(), "stmnt");
      }
    | PRINTLN LPAREN ID RPAREN SEMICOLON
      {
          outlog << "At line no: " << lines
                 << " statement : PRINTLN LPAREN ID RPAREN SEMICOLON "
                 << endl << endl;
          outlog << "printf(" << $3->getname() << ");" << endl << endl;
          $$ = new symbol_info("printf(" + $3->getname() + ");", "stmnt");
      }
    | RETURN expression SEMICOLON
      {
          outlog << "At line no: " << lines
                 << " statement : RETURN expression SEMICOLON "
                 << endl << endl;
          outlog << "return " << $2->getname() << ";" << endl << endl;
          $$ = new symbol_info("return " + $2->getname() + ";", "stmnt");
      }
    ;

expression_statement
    : SEMICOLON
      {
          outlog << "At line no: " << lines << " expression_statement : SEMICOLON " << endl << endl;
          outlog << ";" << endl << endl;
          $$ = new symbol_info(";", "expr_stmt");
      }
    | expression SEMICOLON
      {
          outlog << "At line no: " << lines << " expression_statement : expression SEMICOLON " << endl << endl;
          outlog << $1->getname() << ";" << endl << endl;
          $$ = new symbol_info($1->getname() + ";", "expr_stmt");
      }
    ;

variable
    : ID
      {
          outlog << "At line no: " << lines << " variable : ID " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "varbl");
      }
    | ID LTHIRD expression RTHIRD
      {
          outlog << "At line no: " << lines << " variable : ID LTHIRD expression RTHIRD " << endl << endl;
          outlog << $1->getname() << "[" << $3->getname() << "]" << endl << endl;
          $$ = new symbol_info($1->getname() + "[" + $3->getname() + "]", "varbl");
      }
    ;

expression
    : logic_expression
      {
          outlog << "At line no: " << lines << " expression : logic_expression " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "expr");
      }
    | variable ASSIGNOP logic_expression
      {
          outlog << "At line no: " << lines
                 << " expression : variable ASSIGNOP logic_expression "
                 << endl << endl;
          outlog << $1->getname() << "=" << $3->getname() << endl << endl;
          $$ = new symbol_info($1->getname() + "=" + $3->getname(), "expr");
      }
    ;

logic_expression
    : rel_expression
      {
          outlog << "At line no: " << lines << " logic_expression : rel_expression " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "lgc_expr");
      }
    | rel_expression LOGICOP rel_expression
      {
          outlog << "At line no: " << lines
                 << " logic_expression : rel_expression LOGICOP rel_expression "
                 << endl << endl;
          outlog << $1->getname() << $2->getname() << $3->getname() << endl << endl;
          $$ = new symbol_info($1->getname() + $2->getname() + $3->getname(), "lgc_expr");
      }
    ;

rel_expression
    : simple_expression
      {
          outlog << "At line no: " << lines << " rel_expression : simple_expression " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "rel_expr");
      }
    | simple_expression RELOP simple_expression
      {
          outlog << "At line no: " << lines
                 << " rel_expression : simple_expression RELOP simple_expression "
                 << endl << endl;
          outlog << $1->getname() << $2->getname() << $3->getname() << endl << endl;
          $$ = new symbol_info($1->getname() + $2->getname() + $3->getname(), "rel_expr");
      }
    ;

simple_expression
    : term
      {
          outlog << "At line no: " << lines << " simple_expression : term " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "simp_expr");
      }
    | simple_expression ADDOP term
      {
          outlog << "At line no: " << lines
                 << " simple_expression : simple_expression ADDOP term "
                 << endl << endl;
          outlog << $1->getname() << $2->getname() << $3->getname() << endl << endl;
          $$ = new symbol_info($1->getname() + $2->getname() + $3->getname(), "simp_expr");
      }
    ;

term
    : unary_expression
      {
          outlog << "At line no: " << lines << " term : unary_expression " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "term");
      }
    | term MULOP unary_expression
      {
          outlog << "At line no: " << lines << " term : term MULOP unary_expression " << endl << endl;
          outlog << $1->getname() << $2->getname() << $3->getname() << endl << endl;
          $$ = new symbol_info($1->getname() + $2->getname() + $3->getname(), "term");
      }
    ;

unary_expression
    : ADDOP unary_expression
      {
          outlog << "At line no: " << lines << " unary_expression : ADDOP unary_expression " << endl << endl;
          outlog << $1->getname() << $2->getname() << endl << endl;
          $$ = new symbol_info($1->getname() + $2->getname(), "un_expr");
      }
    | NOT unary_expression
      {
          outlog << "At line no: " << lines << " unary_expression : NOT unary_expression " << endl << endl;
          outlog << "!" << $2->getname() << endl << endl;
          $$ = new symbol_info("!" + $2->getname(), "un_expr");
      }
    | factor
      {
          outlog << "At line no: " << lines << " unary_expression : factor " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "un_expr");
      }
    ;

factor
    : variable
      {
          outlog << "At line no: " << lines << " factor : variable " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "fctr");
      }
    | ID LPAREN argument_list RPAREN
      {
          outlog << "At line no: " << lines << " factor : ID LPAREN argument_list RPAREN " << endl << endl;
          outlog << $1->getname() << "(" << $3->getname() << ")" << endl << endl;
          $$ = new symbol_info($1->getname() + "(" + $3->getname() + ")", "fctr");
      }
    | LPAREN expression RPAREN
      {
          outlog << "At line no: " << lines << " factor : LPAREN expression RPAREN " << endl << endl;
          outlog << "(" << $2->getname() << ")" << endl << endl;
          $$ = new symbol_info("(" + $2->getname() + ")", "fctr");
      }
    | CONST_INT
      {
          outlog << "At line no: " << lines << " factor : CONST_INT " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "fctr");
      }
    | CONST_FLOAT
      {
          outlog << "At line no: " << lines << " factor : CONST_FLOAT " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "fctr");
      }
    | variable INCOP
      {
          outlog << "At line no: " << lines << " factor : variable INCOP " << endl << endl;
          outlog << $1->getname() << "++" << endl << endl;
          $$ = new symbol_info($1->getname() + "++", "fctr");
      }
    | variable DECOP
      {
          outlog << "At line no: " << lines << " factor : variable DECOP " << endl << endl;
          outlog << $1->getname() << "--" << endl << endl;
          $$ = new symbol_info($1->getname() + "--", "fctr");
      }
    ;

argument_list
    : arguments
      {
          outlog << "At line no: " << lines << " argument_list : arguments " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "arg_list");
      }
    |
      {
          outlog << "At line no: " << lines << " argument_list :  " << endl << endl;
          outlog << "" << endl << endl;
          $$ = new symbol_info("", "arg_list");
      }
    ;

arguments
    : arguments COMMA logic_expression
      {
          outlog << "At line no: " << lines << " arguments : arguments COMMA logic_expression " << endl << endl;
          outlog << $1->getname() << "," << $3->getname() << endl << endl;
          $$ = new symbol_info($1->getname() + "," + $3->getname(), "arg");
      }
    | logic_expression
      {
          outlog << "At line no: " << lines << " arguments : logic_expression " << endl << endl;
          outlog << $1->getname() << endl << endl;
          $$ = new symbol_info($1->getname(), "arg");
      }
    ;

%%

int main(int argc, char *argv[])
{
    if (argc != 2) {
        cout << "Usage: " << argv[0] << " <input_file>" << endl;
        return 1;
    }

    yyin = fopen(argv[1], "r");
    if (!yyin) {
        cout << "Could not open file: " << argv[1] << endl;
        return 1;
    }

    outlog.open("22101459_22101458_log.txt", ios::trunc);

    /* Create symbol table with 10 buckets and enter global scope */
    symtab = new symbol_table(10, &outlog);
    symtab->enter_scope();

    yyparse();

    outlog << endl << "Total lines: " << lines << endl;

    outlog.close();
    fclose(yyin);

    delete symtab;
    return 0;
}
